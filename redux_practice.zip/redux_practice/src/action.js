export const sell_cake = (num) => {
    return {
        type: 'buy_cake',
        payload : num
    }
}

export const add_cake = (num) => {
    return {
        type: 'add_cake',
        payload : num
    }
}

