import React from "react";
import Cakes from "./cakes";
import "./App.css";

const App = () => {
  return (
    <div className="App">
      <Cakes />
    </div>
  );
};

export default App;
